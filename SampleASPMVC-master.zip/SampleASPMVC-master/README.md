# SampleASPMVC

Sample untuk blog post ASP.NET MVC

Dibuat dengan menggunakan _Visual Studio Community 2015 Update 2_

Baca artikel terkait di blog [System.Nullify](https://vocalotechno.wordpress.com/2016/05/27/coding-membuat-asp-net-mvc-web-app-sederhana/) 
